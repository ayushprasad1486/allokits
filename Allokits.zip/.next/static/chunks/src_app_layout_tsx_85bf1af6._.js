(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9a168d68._.css",
  "static/chunks/d0d02_next_fd033dcc._.js",
  "static/chunks/40e73_framer-motion_dist_es_eef1b8c4._.js",
  "static/chunks/e546b_motion-dom_dist_es_6b2f7bde._.js",
  "static/chunks/53d50_motion_dist_es_5ba50cdd._.js",
  "static/chunks/node_modules__pnpm_7972724b._.js",
  "static/chunks/src_components_8e5ef23d._.js"
],
    source: "dynamic"
});
