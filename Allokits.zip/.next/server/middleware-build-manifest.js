globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/d0d02_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_e3003895._.js",
    "static/chunks/d0d02_next_dist_compiled_1a34b91c._.js",
    "static/chunks/d0d02_next_dist_client_d1553a8c._.js",
    "static/chunks/d0d02_next_dist_901ee966._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js",
    "static/chunks/_e69f0d32._.js",
    "static/chunks/_61eda6fb._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];