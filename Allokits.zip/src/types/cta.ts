export type CTASectionProps = {
  title: string;
  description: string;
  buttonText: string;
  href: string;
  delay?: number;
};