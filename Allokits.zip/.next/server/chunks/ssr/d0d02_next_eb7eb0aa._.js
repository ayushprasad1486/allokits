module.exports = {

"[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.0_fae39a91a235d4e1e39508504d8a66a5/node_modules/next/navigation.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.0_fae39a91a235d4e1e39508504d8a66a5/node_modules/next/dist/client/components/navigation.js [app-ssr] (ecmascript)");
}}),
"[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.0_fae39a91a235d4e1e39508504d8a66a5/node_modules/next/image.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.0_fae39a91a235d4e1e39508504d8a66a5/node_modules/next/dist/shared/lib/image-external.js [app-ssr] (ecmascript)");
}}),

};

//# sourceMappingURL=d0d02_next_eb7eb0aa._.js.map