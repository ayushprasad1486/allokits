export const categories = [
  "All",
  "Talking Heads",
  "Shorts",
  "Promo",
  "Documentary",
  "Motion Graphics",
];